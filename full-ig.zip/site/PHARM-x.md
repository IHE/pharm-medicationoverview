This section corresponds to transaction [PHARM-xxxx] of the IHE Technical Framework. Transaction [PHARM-xxxxx] is used by x and x actors.
It is used to get the medication overview.



The actors included are the Medication Treatment repository which should have all of part of the medication treatment for a certain patient.

From here, the creates pull data and aggregates it to create the medication overview.



