<figure>
  {% include overview-model.svg %}
  <figcaption>MEOW Data overview</figcaption>
</figure>


* Actors

  - [Medication Repository](actors-transactions.html#133111-medication-repository)

  - [Medication Data Provider](actors-transactions.html#133112-medication-data-provider)

  - [Medication Data Consumer](actors-transactions.html#133113-medication-data-consumer)


* Transactions

  - [Get the Medication Overview \[PHARM-xx\]](PHARM-x.html)

  - [Producing the Medication Overview \[PHARM-yy\]](PHARM-y.html)



<div>
<img alt="Figure: MEOW Workflow overview" src="overview.png" width="100%">
</div>
